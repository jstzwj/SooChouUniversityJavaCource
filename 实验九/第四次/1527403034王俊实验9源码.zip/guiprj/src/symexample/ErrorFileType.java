package symexample;

public class ErrorFileType extends Exception {
	public ErrorFileType(String err){
		super(err);
	}
}
