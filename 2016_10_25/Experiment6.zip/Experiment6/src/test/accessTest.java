package test;

public class accessTest {
	static int x=8;
	public static void main(String[] args){
		System.out.println(x);
	}
}
