package test;

/*
class accessTest {
	static int x=8;
	
}
*/

public class samePackage {
	public static void main(String[] args){
		System.out.println(accessTest.x);
	}
}
