package question2;

public interface Sortable {
	public int Compare(Sortable s);
}
